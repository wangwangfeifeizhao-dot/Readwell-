import { cp, mkdir, readdir, readFile, rm, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, 'dist');
const pages = ['index.html','about.html','library.html','story.html','word-support.html','simplifier.html','read-aloud.html','buddy.html','quiz.html','dashboard.html','settings.html','sdg4.html'];
const assets = ['app.js', 'styles.css'];
const skip = new Set(['dist', 'node_modules', '.vercel', 'scripts']);

function fail(message) { console.error(`Build error: ${message}`); process.exitCode = 1; }
async function validate() {
  for (const file of [...pages, ...assets]) {
    if (!existsSync(path.join(root, file))) fail(`Required file is missing: ${file}`);
  }
  const projectFiles = await readdir(root);
  for (const filename of projectFiles) {
    if (skip.has(filename)) continue;
    const full = path.join(root, filename);
    if ((await stat(full)).isFile() && /\.(html|js|css|json)$/i.test(filename)) {
      const content = await readFile(full, 'utf8');
      if (/([A-Z]:\\|file:\/\/\/|C%3A%2F)/i.test(content)) fail(`Local filesystem path found in ${filename}`);
    }
  }
}

await validate();
if (!process.exitCode && !process.argv.includes('--check')) {
  await rm(output, { recursive: true, force: true });
  await mkdir(output, { recursive: true });
  for (const file of [...pages, ...assets]) await cp(path.join(root, file), path.join(output, file));
  console.log(`Build complete: ${pages.length} pages and ${assets.length} shared assets copied to dist/.`);
}

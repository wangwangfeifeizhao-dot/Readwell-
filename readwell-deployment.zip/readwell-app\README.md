# ReadWell

ReadWell is a responsive, static multi-page reading application for elementary ESL learners. It runs entirely in the browser: no server, API keys, or environment variables are required.

## Deploy to Vercel

1. Create a new Git repository and push the contents of this folder.
2. In Vercel, choose **Add New → Project** and import the repository.
3. Keep the framework preset as **Other**. Vercel will run `npm run build` and publish `dist` automatically.
4. Click **Deploy**.

The clean routes `/library`, `/story`, `/quiz`, `/dashboard`, and the other pages are configured in `vercel.json`; direct refreshes work on every route.

## Local production check

Use Node.js 20 or newer:

```bash
npm run build
```

The generated static deployment folder is `dist/`.
